# Borrador de Data Safety para Google Play - Mascotify

> Este archivo sirve como guía interna para completar la sección Seguridad de los datos en Play Console. No reemplaza la revisión real dentro de la consola ni la validación legal.

## 1. Datos que probablemente recopila Mascotify

### Información personal

- Nombre.
- Email.
- Identificador de usuario.
- Datos de perfil.

Uso principal:

- Crear cuenta.
- Autenticación.
- Soporte.
- Personalización de experiencia.

### Contenido generado por usuarios

- Fotos.
- Videos o clips.
- Mensajes.
- Información de mascotas.
- Certificados documentales de animales, cuando se implemente.

Uso principal:

- Mostrar contenido dentro de la app.
- Permitir interacción social.
- Administrar perfiles de mascotas y profesionales.
- Gestionar certificación documental futura.

### Información de mascotas

Google Play no siempre tiene una categoría exacta para mascotas, pero puede tratarse como contenido proporcionado por el usuario.

- Nombre de mascota.
- Especie.
- Raza.
- Edad.
- Historial.
- QR o trazabilidad.
- Certificados.

### Datos de app y rendimiento

- Registros de fallos.
- Diagnóstico.
- Datos de rendimiento.
- Uso de funciones.

### Información de pagos

Si se implementan suscripciones:

- Estado del plan.
- Identificador de compra.
- Historial de suscripción procesado por Google Play.

Mascotify no debería almacenar datos completos de tarjetas.

## 2. Datos compartidos con terceros

Posibles terceros:

- Backend / hosting.
- Base de datos.
- Cloudinary u otro almacenamiento multimedia.
- Google Play Billing.
- Servicios de analítica o crash reporting, si se implementan.
- AdMob u otro proveedor de anuncios, si se implementan anuncios.

## 3. Seguridad

Declaraciones a evaluar en Play Console:

- Si los datos se transmiten cifrados.
- Si el usuario puede solicitar eliminación de datos.
- Si la app permite eliminar cuenta.
- Si los datos son necesarios para la funcionalidad principal.
- Si hay datos opcionales.

## 4. Anuncios

Primera versión recomendada:

- Si no hay SDK de anuncios integrado: declarar que no contiene anuncios.
- Si en el futuro se incorpora AdMob o publicidad real: declarar que contiene anuncios y actualizar privacidad/Data Safety.

## 5. Público objetivo

Sugerencia inicial:

- No declarar como app dirigida específicamente a niños.
- Declarar público general/adultos si hay comunidad, clips, mensajes o perfiles profesionales.

## 6. Acceso restringido

Si la app requiere login, Play Console puede pedir instrucciones para revisión.

Preparar:

- Cuenta demo familia.
- Cuenta demo profesional.
- Instrucciones de navegación.
- Indicar qué funciones están mockeadas o en desarrollo si corresponde.

## 7. Pendientes para completar correctamente

- Definir email de soporte.
- Definir URL pública de política de privacidad.
- Confirmar si habrá anuncios reales en la primera versión.
- Confirmar si habrá login real o demo.
- Confirmar backend productivo.
- Confirmar Cloudinary productivo.
- Confirmar si hay analytics o crash reporting.
- Confirmar si hay eliminación de cuenta dentro de la app.
