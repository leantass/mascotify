# Descripción de producto y ficha base para Play Store - Mascotify

> Borrador para Play Console. Ajustar antes de cargar en producción.

## 1. Nombre de la app

Mascotify

## 2. Descripción corta

Gestioná tus mascotas, su historial, QR y conexión con profesionales.

## 3. Descripción completa

Mascotify es una aplicación pensada para reunir en un mismo ecosistema a mascotas, familias y profesionales del mundo pet.

Con Mascotify podés crear perfiles de tus mascotas, organizar información importante, acceder a herramientas de trazabilidad mediante QR, consultar historial, recibir notificaciones internas y explorar contenido, perfiles y servicios vinculados al cuidado animal.

La app está diseñada para acompañar tanto a familias como a profesionales. Las familias pueden centralizar la información de sus mascotas, mientras que los profesionales pueden construir presencia dentro del ecosistema, mostrar servicios y, en futuras versiones, acceder a herramientas avanzadas como cuenta verificada, métricas y certificación documental de animales.

### Funciones principales

- Creación y gestión de perfiles de mascotas.
- Historial de eventos por mascota.
- QR e identificadores de trazabilidad.
- Perfil familiar.
- Exploración de contenido y profesionales.
- Mensajería y notificaciones internas.
- Perfil profesional para prestadores del ecosistema pet.
- Clips y contenido social relacionado con mascotas.
- Planes Free, Plus y Pro.
- Funciones futuras de certificación documental de animales.

### Planes

- **Free:** acceso inicial gratuito con funciones básicas.
- **Plus:** plan familiar con más capacidad de gestión para mascotas e integrantes.
- **Pro:** plan profesional con cuenta verificada, uso sin límites visibles y herramientas diferenciales para profesionales, negocios o criadores.

Mascotify busca que el cuidado, la organización y la conexión dentro del mundo pet sean más simples, confiables y accesibles.

## 4. Categoría sugerida

- Principal sugerida: Estilo de vida
- Alternativas posibles: Social, Productividad, Herramientas

La categoría final debe definirse en Play Console según cómo quede la versión publicada.

## 5. Público objetivo sugerido

Sugerencia inicial: público general, jóvenes adultos y adultos.

Evitar declarar la app como dirigida específicamente a niños mientras incluya comunidad, clips, mensajería, perfiles profesionales o contenido generado por usuarios.

## 6. Declaración de anuncios

Primera versión recomendada:

- Si la app NO integra AdMob ni banners reales: declarar que **no contiene anuncios**.
- Si la app integra anuncios reales en el Plan Free: declarar que **sí contiene anuncios**.

## 7. Instrucciones de acceso para revisores

Si Play Console pide acceso para revisar funciones restringidas, usar cuentas demo.

### Cuenta demo familia

- Email: [COMPLETAR EMAIL DEMO]
- Password: [COMPLETAR PASSWORD DEMO]
- Instrucciones: iniciar sesión y revisar dashboard familia, mascotas, perfil, QR, historial y explorar.

### Cuenta demo profesional

- Email: [COMPLETAR EMAIL DEMO]
- Password: [COMPLETAR PASSWORD DEMO]
- Instrucciones: iniciar sesión y revisar dashboard profesional, perfil público, servicios, explorar y funciones Pro disponibles.

No publicar credenciales reales. Usar cuentas temporales de prueba.

## 8. Texto breve sobre la experiencia previa del desarrollador

Cuento con experiencia previa utilizando Google Play Console para publicar aplicaciones Android. En el pasado publiqué dos aplicaciones, “AMD Red League” y “Mascotas”, que actualmente ya no se encuentran activas en la tienda.

El proyecto actual, “Mascotify”, se plantea como una evolución directa de “Mascotas”. A partir de la experiencia obtenida con esa aplicación, se rediseñó el enfoque del producto, se corrigieron limitaciones anteriores y se desarrolló una propuesta más completa, orientada a conectar mascotas, familias y profesionales dentro de un mismo ecosistema digital.
