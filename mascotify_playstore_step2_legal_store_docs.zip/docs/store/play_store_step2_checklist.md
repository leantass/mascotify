# Checklist Play Store - Paso 2 Mascotify

## Documentos creados

- `docs/legal/privacy_policy.md`
- `docs/legal/terms_and_conditions.md`
- `docs/store/play_store_product_description.md`
- `docs/store/data_safety_draft.md`

## Lo que ya está hecho

- Borrador de Política de privacidad.
- Borrador de Términos y condiciones.
- Borrador de descripción corta y descripción completa para Play Store.
- Borrador de Data Safety.
- Texto de experiencia previa con Play Console y Android.
- Criterio recomendado para anuncios.
- Criterio recomendado para público objetivo.
- Instrucciones base para cuentas demo de revisión.

## Lo que falta completar con datos reales

- Razón social.
- CUIT o identificación fiscal.
- Domicilio legal.
- Email de soporte.
- Sitio web.
- URL pública de política de privacidad.
- Fecha final de actualización legal.
- Jurisdicción aplicable.
- Cuentas demo para Google Play.
- Confirmar si hay anuncios reales en la primera versión.
- Confirmar backend productivo.
- Confirmar Cloudinary productivo.
- Confirmar si hay analytics/crash reporting.
- Confirmar si habrá suscripciones reales en la primera publicación.

## Recomendación operativa

Para Google Play, la política de privacidad debe estar en una URL pública activa. GitHub puede servir como respaldo documental, pero para Play Store conviene publicarla también en una web o landing oficial de Mascotify.

## Archivos recomendados en el repo

```text

docs/legal/privacy_policy.md
docs/legal/terms_and_conditions.md
docs/store/play_store_product_description.md
docs/store/data_safety_draft.md
docs/store/play_store_step2_checklist.md
```

## Commit recomendado

```text

docs: add Play Store legal and listing drafts
```
