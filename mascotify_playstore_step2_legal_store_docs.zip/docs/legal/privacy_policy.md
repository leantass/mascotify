# Política de privacidad de Mascotify

**Última actualización:** [COMPLETAR FECHA]  
**Aplicación:** Mascotify  
**Responsable:** [COMPLETAR RAZÓN SOCIAL / NOMBRE LEGAL]  
**CUIT / Identificación fiscal:** [COMPLETAR]  
**Domicilio legal:** [COMPLETAR]  
**Email de contacto:** [COMPLETAR EMAIL DE SOPORTE]  
**Sitio web:** [COMPLETAR URL]

> Este documento es un borrador operativo para Google Play. Debe ser revisado y completado con los datos legales reales antes de publicarse.

## 1. Alcance

Esta Política de privacidad describe cómo Mascotify recopila, utiliza, almacena, protege y eventualmente comparte información de las personas que usan la aplicación.

Mascotify es una aplicación orientada a la gestión de mascotas, perfiles familiares, interacción con profesionales, contenido social vinculado al mundo pet, planes de suscripción y futuras funciones de certificación documental de animales.

## 2. Información que podemos recopilar

Según las funciones utilizadas, Mascotify puede recopilar las siguientes categorías de información:

### 2.1 Información de cuenta

- Nombre y apellido.
- Correo electrónico.
- Identificador de usuario.
- Tipo de perfil o cuenta.
- Preferencias de uso.

### 2.2 Información sobre mascotas

- Nombre de la mascota.
- Edad o fecha aproximada de nacimiento.
- Especie, raza u otros datos descriptivos.
- Historial o eventos asociados a la mascota.
- Identificadores de trazabilidad o QR.
- Fotos o contenido visual relacionado.

### 2.3 Información de perfiles profesionales

Cuando el usuario utiliza funciones profesionales, Mascotify puede recopilar:

- Nombre profesional o comercial.
- Categoría de servicio.
- Descripción del perfil.
- Servicios ofrecidos.
- Datos públicos de contacto.
- Métricas básicas de visibilidad o interacción.
- Estado de cuenta verificada, cuando corresponda.

### 2.4 Contenido generado por usuarios

Mascotify puede permitir la carga o publicación de:

- Clips o videos.
- Imágenes.
- Mensajes.
- Comentarios o interacciones.
- Reportes o avisos vinculados con mascotas.

### 2.5 Certificación documental de animales

En futuras versiones, el Plan Pro puede permitir cargar documentación respaldatoria sobre animales, como certificados veterinarios, vacunación, estudios genéticos, aptitud reproductiva, pedigree, fertilidad, entrenamiento, conducta o documentación emitida por criaderos, asociaciones o entidades certificantes.

Mascotify no emite diagnósticos médicos, genéticos ni veterinarios propios. La aplicación puede funcionar como plataforma de carga, organización, visualización y eventual validación documental, siempre indicando el origen del certificado cuando corresponda.

### 2.6 Información técnica y de uso

Podemos recopilar información técnica necesaria para operar y mejorar la aplicación, como:

- Tipo de dispositivo.
- Sistema operativo.
- Identificadores técnicos.
- Registro de errores.
- Datos de rendimiento.
- Uso de funciones dentro de la aplicación.

### 2.7 Información de pagos y suscripciones

Si Mascotify implementa planes pagos, las compras y suscripciones podrán ser gestionadas por Google Play, App Store u otros proveedores autorizados. Mascotify no debería almacenar datos completos de tarjetas de crédito o medios de pago. La aplicación puede recibir información sobre el estado de la suscripción, como plan activo, vencimiento, renovación o cancelación.

## 3. Finalidades del uso de la información

La información puede utilizarse para:

- Crear y gestionar cuentas de usuario.
- Permitir la carga y administración de mascotas.
- Mostrar perfiles de mascotas y profesionales.
- Generar identificadores QR o herramientas de trazabilidad.
- Gestionar historial, notificaciones y mensajes.
- Permitir funciones sociales y de clips.
- Mejorar la experiencia de usuario.
- Prevenir abuso, spam, fraude o uso indebido.
- Brindar soporte técnico.
- Gestionar planes Free, Plus y Pro.
- Validar funciones premium o de suscripción.
- Implementar futuras funciones de certificación documental.
- Cumplir obligaciones legales o requerimientos de plataformas.

## 4. Compartición de información

Mascotify puede compartir información solo cuando sea necesario para prestar el servicio, cumplir obligaciones legales o utilizar proveedores técnicos.

La información puede ser procesada por proveedores como:

- Servicios de hosting o backend.
- Bases de datos.
- Servicios de almacenamiento multimedia, como Cloudinary u otros equivalentes.
- Servicios de autenticación.
- Proveedores de analítica, si se implementan.
- Plataformas de pago o suscripción, como Google Play Billing.
- Proveedores de publicidad, si se implementan anuncios en el futuro.

No vendemos datos personales de los usuarios.

## 5. Publicidad

Mascotify puede implementar publicidad en el Plan Free en versiones futuras. Si se incorporan anuncios, podrán utilizarse proveedores publicitarios como Google AdMob u otros servicios similares.

En ese caso, se actualizará esta Política de privacidad y se informará en Google Play Console que la aplicación contiene anuncios.

Las funciones Plus y Pro podrán reducir o eliminar anuncios según el modelo comercial vigente.

## 6. Seguridad de la información

Mascotify debe aplicar medidas razonables para proteger la información de los usuarios, incluyendo controles de acceso, cifrado cuando corresponda, almacenamiento seguro y buenas prácticas de desarrollo.

Ningún sistema es completamente infalible, pero se buscará reducir riesgos de acceso no autorizado, pérdida, alteración o uso indebido de la información.

## 7. Conservación de datos

La información se conservará mientras sea necesaria para prestar el servicio, cumplir obligaciones legales, resolver disputas, prevenir abuso o mantener registros operativos.

Los usuarios podrán solicitar la eliminación de su cuenta o de determinados datos, sujeto a limitaciones técnicas, legales o de seguridad.

## 8. Derechos de los usuarios

Según la normativa aplicable, los usuarios pueden solicitar acceso, corrección, eliminación, limitación u oposición al tratamiento de sus datos.

Las solicitudes podrán enviarse a: [COMPLETAR EMAIL DE SOPORTE]

## 9. Menores de edad

Mascotify está pensada para usuarios generales, familias y profesionales del ecosistema pet. No debe dirigirse específicamente a menores de edad sin controles y políticas adicionales.

Si en el futuro se decide orientar la aplicación a menores o incluirlos como público objetivo, se deberán revisar y adaptar las políticas de privacidad, seguridad, consentimiento y contenido familiar.

## 10. Contenido generado por usuarios

Los usuarios son responsables del contenido que cargan, publican o comparten en Mascotify.

Mascotify podrá moderar, ocultar, eliminar o restringir contenido que infrinja normas de convivencia, derechos de terceros, políticas de la plataforma o leyes aplicables.

## 11. Cambios en esta política

Mascotify puede actualizar esta Política de privacidad para reflejar cambios del producto, requisitos legales o modificaciones de servicios utilizados.

La fecha de última actualización se modificará cuando se realicen cambios relevantes.

## 12. Contacto

Para consultas sobre privacidad o tratamiento de datos, contactarse a:

- **Email:** [COMPLETAR EMAIL DE SOPORTE]
- **Responsable:** [COMPLETAR]
- **Sitio web:** [COMPLETAR URL]
