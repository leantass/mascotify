# Términos y condiciones de Mascotify

**Última actualización:** [COMPLETAR FECHA]  
**Aplicación:** Mascotify  
**Responsable:** [COMPLETAR RAZÓN SOCIAL / NOMBRE LEGAL]  
**Email de contacto:** [COMPLETAR EMAIL DE SOPORTE]

> Este documento es un borrador operativo. Debe ser revisado legalmente antes de publicarse.

## 1. Aceptación de los términos

Al acceder o utilizar Mascotify, el usuario acepta estos Términos y condiciones. Si no está de acuerdo, no debe utilizar la aplicación.

## 2. Descripción del servicio

Mascotify es una aplicación destinada a la gestión de mascotas, perfiles familiares, trazabilidad mediante QR, historial, interacción con profesionales, contenido social vinculado al ecosistema pet, planes de suscripción y futuras funciones de certificación documental de animales.

Mascotify puede incluir funciones gratuitas y funciones pagas, según el plan contratado.

## 3. Planes disponibles

Mascotify puede ofrecer los siguientes planes:

- **Free:** plan gratuito con funciones limitadas.
- **Plus:** plan pago orientado a familias y tutores, con más capacidad de gestión.
- **Pro:** plan pago orientado a profesionales, negocios y prestadores del ecosistema pet, con cuenta verificada, uso sin límites visibles y futuras funciones de certificación documental de animales.

Los precios, funciones y límites pueden modificarse con el tiempo. Los cambios relevantes serán informados cuando corresponda.

## 4. Cuenta de usuario

El usuario se compromete a proporcionar información verdadera, actualizada y completa. También es responsable de mantener la confidencialidad de sus credenciales y de toda actividad realizada desde su cuenta.

Mascotify puede suspender o restringir cuentas que incumplan estos términos, realicen abuso del servicio, publiquen contenido prohibido o afecten la seguridad de otros usuarios.

## 5. Uso permitido

El usuario se compromete a utilizar Mascotify de forma legal, responsable y respetuosa.

Está prohibido:

- Publicar información falsa, engañosa o fraudulenta.
- Suplantar identidad.
- Subir contenido ofensivo, ilegal, discriminatorio, violento o sexual.
- Usar la app para acoso, spam o fraude.
- Intentar vulnerar la seguridad de la plataforma.
- Cargar documentación falsa o adulterada.
- Utilizar certificados de animales de forma engañosa.
- Publicar servicios profesionales sin autorización o capacidad para prestarlos.

## 6. Mascotas y perfiles

Los usuarios pueden cargar información sobre sus mascotas. El usuario declara que tiene derecho o autorización para publicar y administrar esa información.

Mascotify no garantiza la exactitud de la información cargada por los usuarios sobre mascotas, razas, historial, certificados, comportamiento, fertilidad o cualquier otro dato.

## 7. Certificación documental de animales

En versiones futuras, Mascotify puede permitir que usuarios Pro carguen documentación respaldatoria de animales, como certificados veterinarios, estudios genéticos, pedigree, certificados reproductivos o documentos emitidos por entidades externas.

Mascotify no actúa como veterinaria, laboratorio genético, entidad médica ni autoridad certificante salvo que se indique expresamente un acuerdo con un tercero autorizado.

Cuando se muestren certificados, deberá indicarse el origen del documento y, si corresponde, el estado de revisión o validación.

El usuario es responsable por la autenticidad, legalidad y exactitud de la documentación que cargue.

## 8. Contenido generado por usuarios

Los usuarios pueden cargar o publicar contenido, como textos, imágenes, videos, clips, mensajes, datos de mascotas, certificados, reportes o información profesional.

El usuario conserva los derechos sobre su contenido, pero autoriza a Mascotify a alojarlo, mostrarlo, procesarlo y distribuirlo dentro de la aplicación para prestar el servicio.

Mascotify podrá moderar, ocultar, eliminar o restringir contenido que infrinja estos términos, derechos de terceros o normas legales.

## 9. Servicios profesionales

Los perfiles profesionales, comercios o prestadores son responsables por la veracidad de sus datos, servicios, disponibilidad, precios y condiciones.

Mascotify puede facilitar la conexión entre usuarios y profesionales, pero no garantiza la calidad, disponibilidad, seguridad o resultado de los servicios prestados por terceros.

Cualquier contratación entre usuarios y profesionales se realiza bajo responsabilidad de las partes involucradas.

## 10. Pagos y suscripciones

Mascotify puede ofrecer planes pagos mediante Google Play, App Store u otros proveedores de pago autorizados.

La gestión de cobros, renovaciones, cancelaciones, reembolsos o impuestos puede depender de la plataforma utilizada.

Los usuarios deberán revisar las condiciones específicas de cada tienda o proveedor de pagos.

## 11. Publicidad y sponsors

Mascotify puede mostrar publicidad, promociones, sponsors o contenidos destacados, especialmente en el Plan Free.

Cuando corresponda, el contenido patrocinado deberá identificarse como anuncio, patrocinado o profesional destacado.

## 12. Limitación de responsabilidad

Mascotify se proporciona en el estado en que se encuentra. No se garantiza disponibilidad ininterrumpida, ausencia total de errores ni resultados específicos.

Mascotify no reemplaza el asesoramiento veterinario, legal, profesional o especializado.

Ante emergencias veterinarias, sanitarias, legales o de seguridad, el usuario debe acudir a un profesional o autoridad competente.

## 13. Modificaciones del servicio

Mascotify puede modificar, suspender o discontinuar funciones, planes, precios o condiciones del servicio. Los cambios importantes se comunicarán cuando corresponda.

## 14. Terminación

El usuario puede dejar de usar Mascotify en cualquier momento. Mascotify puede suspender o cerrar cuentas que incumplan estos términos o afecten el funcionamiento del servicio.

## 15. Legislación aplicable

Estos términos se regirán por la legislación aplicable según el domicilio del responsable del servicio, salvo que normas imperativas dispongan otra cosa.

[COMPLETAR JURISDICCIÓN]

## 16. Contacto

Para consultas sobre estos términos:

- **Email:** [COMPLETAR EMAIL DE SOPORTE]
- **Responsable:** [COMPLETAR]
- **Sitio web:** [COMPLETAR URL]
